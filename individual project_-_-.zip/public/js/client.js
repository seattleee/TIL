$(document).ready(function(){

    $(document).on('click', '#register_board', function(){
        const id=$("#new_id").val();
        const pw=$("#new_pw").val();
        const email=$("#new_email").val();

        const send_param={id, pw, email};
        $.post('/register', send_param, function(returnData){
            alert(returnData.message);
            $('#registermodel').modal("hide");
        });
    });

    $("#post_btn_back").click(function(){
        $.post('/',{},(returnData)=>{
            console.log(returnData);
            $("#container_").html(returnData);
        });
    });

    $("#register-form").click(function(){
        $.post('/crew/login-form',{},(returnData)=>{
            $("#container_").html(returnData);
        });
    });
    
    $("#login_board").click(function(){
        $.get('/crew/login-form',{},(returnData)=>{
            $("#container_").html(returnData);
        });
    });

    $("#register_board").click(()=>{
        $.get('/crew/register-form',{},(returnData)=>{
            $("#container_").html(returnData);
        });
    });
    
    $('#uploading_board').click(function(){
/*         const name=$('#name').val();
        const age=$('#age').val();
        const married=$('input[name="married"]').is(":checked");
        const send_param={
            name, age, married
        } */

        $.post('/crew/post-form',{},(returnData)=>{
            $('#container_').html(returnData);
        });
        
        /* $.post('/member/add',send_param, function(returnData){
            alert(returnData.message);
        }); */
    });

    $(document).on('click','#post_save_btn',function(){
        alert('탓지롱');
    });
});