const express=require('express');
const router=express.Router();

router.post('/post-form',(req,res)=>{
    res.render('post-form', {title:"타이틀"});
});

router.get('/login-form',(req,res)=>{
    res.render('login-form', {});
});

router.get('/register-form',(req,res)=>{
    res.render('register-form', {});
});

module.exports=router;