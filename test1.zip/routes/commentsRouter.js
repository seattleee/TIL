const express =require('express');
const router=express.Router();
const User=require('../schemas/user');

router.post('/delete',(req,res)=>{
    const myquery = { _id: mongo.ObjectID(req.body._id)};
    dbo.collection("member").deleteOne(myquery, function(err, obj) {
        if (err){
            console.log(err);
            res.json({message:false});
        }else{
            res.json({message:true});
        }
    });
});

router.post('/update',(req,res)=>{
    const myquery={_id: mongo.ObjectId(req.body._id)};
    var newvalues = { $set: {name: req.body.name, age:req.body.age, married:req.body.married} };
    dbo.collection("member").updateOne(myquery, newvalues, function(err, result) {
      if (err) {
        console.log(err);
        res.json({message:false});
      }else{
        res.json({message:true});
      }
    });
});

router.post('/add_',(req,res)=>{
            dbo.collection("comment").find({}).toArray(function(err, result) {
                if (err) {
                    console.log(err);
                    res.json({message:false});
                }else{
                    res.json({message:result});
                }
          });
    });

module.exports=router;