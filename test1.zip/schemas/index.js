const mongoose=require('mongoose');

module.exports=()=>{
    const connect=()=>{
        if(process.env.NODE_ENV !=='production'){
            mongoose.set('debug',true);
        }
        mongoose.connect('mongodb://localhost:27017/nodejs',{dbName:'nodejs'},(err)=>{
            if(err){
                console.log("con error",err);
            }else{
                console.log('con ok');
            }
        });
    };
    connect();
    mongoose.connection.on('error',(err)=>{
        console.log('몽고DB 연결 에러', err);
    });
    mongoose.connection.on('disconnected',()=>{
        console.log("연결재시도");
        connect();
    });
    require('./user');
    require('./comment');
};